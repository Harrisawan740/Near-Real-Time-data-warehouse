package com.meshJoin.meshJoin;

public class ProductsMDT {

	public String PRODUCT_ID;
	public String PRODUCT_NAME ;
	public String SUPPLIER_ID ;
	public String SUPPLIER_NAME; 
	public double PRICE;
	
	public void display() {
		System.out.println("ProductID: "+" "+this.PRODUCT_ID);
		System.out.println("ProductName: "+" "+this.PRODUCT_NAME);
		System.out.println("SupplierID: "+" "+this.SUPPLIER_ID);
		System.out.println("SupplierName: "+" "+this.SUPPLIER_NAME);
		System.out.println("Price: "+" "+this.PRICE);
	}

	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}

	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}

	public String getPRODUCT_NAME() {
		return PRODUCT_NAME;
	}

	public void setPRODUCT_NAME(String pRODUCT_NAME) {
		PRODUCT_NAME = pRODUCT_NAME;
	}

	public String getSUPPLIER_ID() {
		return SUPPLIER_ID;
	}

	public void setSUPPLIER_ID(String sUPPLIER_ID) {
		SUPPLIER_ID = sUPPLIER_ID;
	}

	public String getSUPPLIER_NAME() {
		return SUPPLIER_NAME;
	}

	public void setSUPPLIER_NAME(String sUPPLIER_NAME) {
		SUPPLIER_NAME = sUPPLIER_NAME;
	}

	public double getPRICE() {
		return PRICE;
	}

	public void setPRICE(double pRICE) {
		PRICE = pRICE;
	}
	
}
