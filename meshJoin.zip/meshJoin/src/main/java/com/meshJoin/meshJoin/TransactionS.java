package com.meshJoin.meshJoin;
import java.sql.Date;
public class TransactionS {

	public double TRANSACTION_ID;
	public String PRODUCT_ID; 
	public String PRODUCT_NAME;
	public String SUPPLIER_ID;
	public String SUPPLIER_NAME;
	public String CUSTOMER_ID;
	public double getTRANSACTION_ID() {
		return TRANSACTION_ID;
	}

	public void setTRANSACTION_ID(double tRANSACTION_ID) {
		TRANSACTION_ID = tRANSACTION_ID;
	}

	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}

	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}

	public String getPRODUCT_NAME() {
		return PRODUCT_NAME;
	}

	public void setPRODUCT_NAME(String pRODUCT_NAME) {
		PRODUCT_NAME = pRODUCT_NAME;
	}

	public String getSUPPLIER_ID() {
		return SUPPLIER_ID;
	}

	public void setSUPPLIER_ID(String sUPPLIER_ID) {
		SUPPLIER_ID = sUPPLIER_ID;
	}

	public String getSUPPLIER_NAME() {
		return SUPPLIER_NAME;
	}

	public void setSUPPLIER_NAME(String sUPPLIER_NAME) {
		SUPPLIER_NAME = sUPPLIER_NAME;
	}

	public String getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}

	public void setCUSTOMER_ID(String cUSTOMER_ID) {
		CUSTOMER_ID = cUSTOMER_ID;
	}

	public String getCUSTOMER_NAME() {
		return CUSTOMER_NAME;
	}

	public void setCUSTOMER_NAME(String cUSTOMER_NAME) {
		CUSTOMER_NAME = cUSTOMER_NAME;
	}

	public String getSTORE_ID() {
		return STORE_ID;
	}

	public void setSTORE_ID(String sTORE_ID) {
		STORE_ID = sTORE_ID;
	}

	public String getSTORE_NAME() {
		return STORE_NAME;
	}

	public void setSTORE_NAME(String sTORE_NAME) {
		STORE_NAME = sTORE_NAME;
	}

	public Date getT_DATE() {
		return T_DATE;
	}

	public void setT_DATE(Date t_DATE) {
		T_DATE = t_DATE;
	}

	public double getQUANTITY() {
		return QUANTITY;
	}

	public void setQUANTITY(double qUANTITY) {
		QUANTITY = qUANTITY;
	}

	public double getSales() {
		return Sales;
	}

	public void setSales(double sales) {
		Sales = sales;
	}

	public String CUSTOMER_NAME;
	public String STORE_ID; 
	public String STORE_NAME; 
	public Date T_DATE;
	public double QUANTITY;
	public double Sales;
	
	public void display() {
		System.out.println("TransactionID: "+" "+this.TRANSACTION_ID);
		System.out.println("ProductID:"+" "+this.PRODUCT_ID+"\n"+"ProductName: "+this.PRODUCT_NAME+"\n"+"SupplierID: "+this.SUPPLIER_ID+"\n"+"SupplierName: "+this.SUPPLIER_NAME+"\n"+"CustomerID: "+this.CUSTOMER_ID+"\n"+"CustomerName: "+this.CUSTOMER_NAME+"\n"+"StoreID: "+this.STORE_ID+"\n"+"StoreName: "+this.STORE_NAME);
		System.out.println("Date: "+this.T_DATE);
		System.out.println("Sales:"+this.Sales);
		System.out.println("Quantity: "+this.QUANTITY+"\n\n");
	}
	
}
