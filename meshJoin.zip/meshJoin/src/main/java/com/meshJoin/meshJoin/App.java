package com.meshJoin.meshJoin;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.Scanner;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;


public class App 
{

    ListMultimap<String, TransactionS> HASHTABLE = ArrayListMultimap.create();
    ArrayList<CustomersMDT> CustomersdiskBuffer= new ArrayList<CustomersMDT>();
    ArrayList<ProductsMDT> ProductsdiskBuffer= new ArrayList<ProductsMDT>();
    
    int index = 0;
    int totalTransaction = 0;
    Queue<ArrayList<IDS>> StreamQueue = new LinkedList<ArrayList<IDS>>();
    
    public Connection connection;
    public Connection warehouseconnection;
    App(){
    	try {
    		Scanner sc= new Scanner(System.in);
    		System.out.println("Enter PORT: ");
    		String port= sc.nextLine(); 
    		
    		System.out.println("Enter DB: ");
    		String db= sc.nextLine(); 
    		
    		System.out.println("Enter ROOT: ");
    		String root= sc.nextLine(); 
    		
    		System.out.println("Enter PASSWORD: ");
    		String password= sc.nextLine();  
    		
    		
    		
			connection = DriverManager.getConnection("jdbc:mysql://localhost:"+String.valueOf(port)+"/"+db, root, password);// Master Data Connection
			warehouseconnection = DriverManager.getConnection("jdbc:mysql://localhost:"+String.valueOf(port)+"/metrowarehouse", root, password);// Warehouse Connection
			System.out.println("Connected With the database successfully");
			String sql=("Select count(*) from transactions");
	        PreparedStatement pstmt = this.connection.prepareStatement(sql);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next())
	        	totalTransaction = rs.getInt(1);
	        
	        System.out.println(totalTransaction);
		} catch (SQLException e) {
			System.out.println("Error while connecting to the database");
		}
    }
    
    public void getProductMD(Integer id) throws SQLException {
    	
    	
        this.ProductsdiskBuffer.clear();
        String sql = ("SELECT a.PRODUCT_ID, a.PRODUCT_NAME, a.SUPPLIER_ID, a.SUPPLIER_NAME, a.PRICE FROM\n" +
                "    (SELECT *, ROW_NUMBER() OVER ( ORDER BY PRODUCT_ID ) row_num FROM  PRODUCTS) as a\n" +
                "WHERE a.row_num>?\n" +
                "LIMIT 20;");
        PreparedStatement pstmt = this.connection.prepareStatement(sql);
        pstmt.setInt(1, id);
        ResultSet rs = pstmt.executeQuery();
        while(rs.next()) {
            ProductsMDT temp = new ProductsMDT();
            temp.PRODUCT_ID=rs.getString(1);
            temp.PRODUCT_NAME=rs.getString(2);
            temp.SUPPLIER_ID=rs.getString(3);
            temp.SUPPLIER_NAME=rs.getString(4);
            temp.PRICE=rs.getDouble(5);
            this.ProductsdiskBuffer.add(temp);
        }
        
    }
    public void getCustomerMD(Integer id)throws SQLException{
    	
    	
    	this.CustomersdiskBuffer.clear();
    	String sql = ("SELECT a.CUSTOMER_ID, a.CUSTOMER_NAME FROM\n" +
                "    (SELECT *, ROW_NUMBER() OVER ( ORDER BY CUSTOMER_ID ) row_num FROM  CUSTOMERS) as a\n" +
                "WHERE a.row_num > ?\n" +
                "LIMIT 10;");
        PreparedStatement pstmt = this.connection.prepareStatement(sql);
        pstmt.setInt(1, id);
        ResultSet rs = pstmt.executeQuery();
        while(rs.next()) {
            CustomersMDT temp = new CustomersMDT();
            temp.CUSTOMER_ID=rs.getString(1);
            temp.CUSTOMER_NAME=rs.getString(2);
            this.CustomersdiskBuffer.add(temp);
        }
    }
    public int getTransactions(Integer id) throws SQLException {
    	int newid = 0;
    	ArrayList<IDS> IDs= new ArrayList<IDS>();
    	
        String sql = ("SELECT * FROM transactions where TRANSACTION_ID > ? ORDER BY TRANSACTION_ID ASC LIMIT ?;");
        PreparedStatement pstmt = this.connection.prepareStatement(sql);
        pstmt.setInt(1, id);
        pstmt.setInt(2, 5);
        ResultSet rs = pstmt.executeQuery();
        while(rs.next()) {
            newid=rs.getInt("TRANSACTION_ID");
            TransactionS temp = new TransactionS();
            temp.TRANSACTION_ID=newid;
            temp.PRODUCT_ID=rs.getString("PRODUCT_ID");
            temp.CUSTOMER_ID=rs.getString("CUSTOMER_ID");
            temp.STORE_ID=rs.getString("STORE_ID");
            temp.STORE_NAME=rs.getString("STORE_NAME");
            temp.T_DATE=rs.getDate("T_DATE");
            temp.QUANTITY=rs.getInt("QUANTITY");

            IDs.add(new IDS(temp.CUSTOMER_ID,temp.PRODUCT_ID));
//            PIDs.add(temp.PRODUCT_ID);
//            CIDs.add(temp.CUSTOMER_ID); 
            this.HASHTABLE.put(String.valueOf(index), temp);
            index++;
        }
        StreamQueue.add(IDs);
        return newid;
    }
    public void runQuery() throws SQLException {
    	int TransactionsTotal = 0 ;																										// connection
		String sql=("Select count(*) from STORE");
        PreparedStatement pstmt = warehouseconnection.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next())
        	TransactionsTotal = rs.getInt(1);
    }
    public void display() {
    	for(int i = 0 ;i<this.StreamQueue.size() ;i++) {
    		System.out.print( this.StreamQueue);
    	}
    }
    public void insertStore(String store_id, String store_name) throws SQLException {
    	 String sql=("INSERT INTO STORE(STORE_ID,STORE_NAME)\n" +
                 "SELECT * FROM\n" +
                 "    (SELECT ? as STORE_ID, ? as STORE_NAME) as a\n" +
                 "WHERE NOT exists(\n" +
                 "        SELECT STORE_ID FROM STORE WHERE STORE_ID = ?\n" +
                 "    );");
         PreparedStatement pstmt=this.warehouseconnection.prepareStatement(sql);
         pstmt.setString(1, store_id);pstmt.setString(2, store_name);pstmt.setString(3, store_id);pstmt.executeUpdate();
    }
    public void insertCustomer(String cust_id,String cust_name) throws SQLException {
    	String sql=("INSERT INTO CUSTOMERS(CUST_ID,CUST_NAME)\n" +
                "SELECT * FROM\n" +
                "    (SELECT ? as CUST_ID, ? as CUST_NAME) as a\n" +
                "WHERE NOT exists(\n" +
                "        SELECT CUST_ID FROM CUSTOMERS WHERE CUST_ID = ?\n" +
                "    );");
        PreparedStatement pstmt=this.warehouseconnection.prepareStatement(sql);
        pstmt.setString(1, cust_id);pstmt.setString(2, cust_name);pstmt.setString(3, cust_id);pstmt.executeUpdate();
    }
    public void insertSupplier(String supplier_id, String supp_name) throws SQLException {
    	String sql=("INSERT INTO SUPPLIER(SUPPLIER_ID,SUPPLIER_Name)\n" +
                "SELECT * FROM\n" +
                "    (SELECT ? as SUPPLIER_ID, ? as SUPPLIER_Name) as a\n" +
                "WHERE NOT exists(\n" +
                "        SELECT SUPPLIER_ID FROM SUPPLIER WHERE SUPPLIER_ID = ?\n" +
                "    );");
        PreparedStatement pstmt = this.warehouseconnection.prepareStatement(sql);
        pstmt.setString(1, supplier_id);pstmt.setString(2, supp_name);pstmt.setString(3, supplier_id);pstmt.executeUpdate();
    }
    public void insertProduct(String p_id,String p_name) throws SQLException {
    	String sql=("INSERT INTO PRODUCTS(P_ID,P_NAME)\n" +
                "SELECT * FROM\n" +
                "    (SELECT ? as P_ID, ? as P_NAME) as a\n" +
                "WHERE NOT exists(\n" +
                "        SELECT P_ID FROM PRODUCTS WHERE P_ID = ?\n" +
                "    );");
        PreparedStatement pstmt=this.warehouseconnection.prepareStatement(sql);
        pstmt.setString(1, p_id);pstmt.setString(2, p_name);pstmt.setString(3, p_id);pstmt.executeUpdate();
    }
    public void insertFacttableData(double tid, String pid, String cid, String sid, Date date, String suid, double q, double sale) throws SQLException{
    	   String sql=("INSERT INTO METROSTORE value (?, ?, ?, ?, ?, ?, ?, ?);");
       
	        PreparedStatement pstmt=this.warehouseconnection.prepareStatement(sql);
	        pstmt.setDouble(1, tid);
	        pstmt.setString(2, pid);
	        pstmt.setString(3, cid);
	        pstmt.setString(4, sid);
	        pstmt.setDate(5, date);
	        pstmt.setString(6,suid);
	        pstmt.setDouble(7,q);
	        pstmt.setDouble(8,sale);
	        pstmt.executeUpdate();
    }
    public void insertDate(Date date) throws SQLException {
        String sql5=("INSERT INTO TIME(DATE,DAY, MONTH, QUARTER, YEAR)\n" +
                "SELECT * FROM\n" +
                "    (SELECT ? as DATE, ? as DAY, ? as MONTH, ? as QUARTER, ? as YEAR) as a\n" +
                "WHERE NOT exists(\n" +
                "        SELECT DATE FROM time WHERE DATE = ?\n" +
                "    );");
        PreparedStatement pstmt=this.warehouseconnection.prepareStatement(sql5);
        pstmt.setDate(1,  date);
        String day= new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date);
        pstmt.setString(2, day);
        pstmt.setInt(3, date.getMonth()+1);
        int q;
        if (date.getMonth()+1 <=3)
            q=1;
        else if (date.getMonth()+1 <=6)
            q=2;
        else if (date.getMonth()+1 <=9)
            q=3;
        else
            q=4;
        pstmt.setInt(4, q);
        int year=date.getYear()+1900;
        pstmt.setInt(5, year);
        pstmt.setDate(6, date);
        pstmt.executeUpdate();
    }
    public void loadTuple(List<TransactionS> tuple_to_load) throws SQLException {
    	this.insertSupplier(tuple_to_load.get(0).SUPPLIER_ID, tuple_to_load.get(0).SUPPLIER_NAME);

    	this.insertCustomer(tuple_to_load.get(0).CUSTOMER_ID, tuple_to_load.get(0).CUSTOMER_NAME);

        this.insertStore(tuple_to_load.get(0).STORE_ID, tuple_to_load.get(0).STORE_NAME);

        this.insertProduct(tuple_to_load.get(0).PRODUCT_ID,tuple_to_load.get(0).PRODUCT_NAME);

        this.insertDate(tuple_to_load.get(0).T_DATE);

    
        this.insertFacttableData(tuple_to_load.get(0).TRANSACTION_ID,tuple_to_load.get(0).PRODUCT_ID,tuple_to_load.get(0).CUSTOMER_ID, tuple_to_load.get(0).STORE_ID,tuple_to_load.get(0).T_DATE, tuple_to_load.get(0).SUPPLIER_ID, tuple_to_load.get(0).QUANTITY,tuple_to_load.get(0).Sales) ;
    }
    public void applyMeshJoin() throws SQLException {
        
        int k = 0;
        
        System.out.println("Working!!!");
        for (int i=0; i<totalTransaction; ){
            i=this.getTransactions(i);
            
            ArrayList<List<TransactionS>> Tdata = new ArrayList<List<TransactionS>>();
            
            for (int x=0; x<5; x++,k++){
            	
            	List<TransactionS> match= this.HASHTABLE.get(String.valueOf(k));
            	
            	Tdata.add(match);
            	
            }
            int j = 0,q = 0;
            
            for (int y = 0 ; y < 5 ;q+=20) {
            
            	if( q == 100)q=0;
            	
                this.getProductMD(q);
                boolean flag = false;
                for (int p = 0; p < 20; p++) {
            		
            		
            		if(Tdata.get(y).get(0).PRODUCT_ID.equals( this.ProductsdiskBuffer.get(p).PRODUCT_ID )) {
//	            		System.out.println("HERE");
	            		
	            		Tdata.get(y).get(0).PRODUCT_NAME = this.ProductsdiskBuffer.get(p).PRODUCT_NAME;
	            		Tdata.get(y).get(0).SUPPLIER_ID = this.ProductsdiskBuffer.get(p).SUPPLIER_ID;
	            		Tdata.get(y).get(0).SUPPLIER_NAME = this.ProductsdiskBuffer.get(p).SUPPLIER_NAME;
	            		Tdata.get(y).get(0).Sales = this.ProductsdiskBuffer.get(p).PRICE * Tdata.get(y).get(0).QUANTITY;
	            		flag = true;
            		}	
				}
            	if(flag) {
            		y++;q=-20;
            	}
            
            }
            for (int y = 0 ; y < 5 ; j+=10) {
            	
            	if( j==50 )j=0;
                this.getCustomerMD(j);
                
                boolean flag = false;
            	for (int c = 0; c < 10; c++) {
            		
            		if(Tdata.get(y).get(0).CUSTOMER_ID.equals(this.CustomersdiskBuffer.get(c).CUSTOMER_ID)) {
            			Tdata.get(y).get(0).CUSTOMER_NAME = this.CustomersdiskBuffer.get(c).CUSTOMER_NAME;
            			flag = true;
            			
            		}	
				}
            	if(flag) {
            		y++;
        			j=-10;
            	}
            
            }
            
            for (int m = 0;m < Tdata.size();m++) {
	            
            	this.loadTuple(Tdata.get(m));
            }
            
        }
        System.out.println("Done!!!");
    }
	public static void main( String[] args ) throws SQLException
    {
    	App app = new App();
    	app.applyMeshJoin();
    }
    
}
