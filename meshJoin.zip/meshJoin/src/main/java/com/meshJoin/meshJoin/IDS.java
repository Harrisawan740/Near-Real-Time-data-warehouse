package com.meshJoin.meshJoin;

public class IDS {
	
	public String PRODUCT_ID; 
	public String CUSTOMER_ID;
	IDS(String c,String p){
		this.CUSTOMER_ID = c;
		this.PRODUCT_ID = p;
	}
	public void display() {
		System.out.println(this.PRODUCT_ID+" "+this.CUSTOMER_ID);
	}
	public String getPRODUCT_ID() {
		return PRODUCT_ID;
	}
	public void setPRODUCT_ID(String pRODUCT_ID) {
		PRODUCT_ID = pRODUCT_ID;
	}
	public String getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}
	public void setCUSTOMER_ID(String cUSTOMER_ID) {
		CUSTOMER_ID = cUSTOMER_ID;
	}
}
