package com.meshJoin.meshJoin;

public class CustomersMDT {

	public String CUSTOMER_ID;
	public String CUSTOMER_NAME;
	
	public void display() {
		System.out.println("CUSTOMERID: "+" "+this.CUSTOMER_ID);
		System.out.println("CUSTOMERName: "+" "+this.CUSTOMER_NAME);
	}

	public String getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}

	public void setCUSTOMER_ID(String cUSTOMER_ID) {
		CUSTOMER_ID = cUSTOMER_ID;
	}

	public String getCUSTOMER_NAME() {
		return CUSTOMER_NAME;
	}

	public void setCUSTOMER_NAME(String cUSTOMER_NAME) {
		CUSTOMER_NAME = cUSTOMER_NAME;
	}
}
